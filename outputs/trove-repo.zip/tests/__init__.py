"""Tests for Trove Fetcher application."""

