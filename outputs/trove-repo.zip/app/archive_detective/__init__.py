from .router import init_archive_detective

__all__ = ["init_archive_detective"]
